import time



lookup = {
    "vraag": "ans"
}

print(lookup["vraag"])
def esketit():
    combor = input("ass")
    lookup.update({"vraag": combor})

esketit()
print(lookup["vraag"])
