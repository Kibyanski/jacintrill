import time

import requests
GOON = {
    "content" : "NIEUWE INLOG MET EMAIL, KIJK SNEL PANEEEL"
}
SMS = {
    "content" : "NIEUWE SMS CODE, KIJK SNEL PANEEEL"
}
cash = {
    "content" : "CASHAPP GOON"
}

header = {
    'authorization': 'OTI3NTg0NzAwOTU0OTc2Mjg2.GNLt05.AV4Ag_eYHmXrcD297ZRwp19XrHac-GZfnbqlbQ'
}
while True:
    r = requests.post("https://discord.com/api/v9/channels/969752367278985226/messages", data=SMS, headers=header)
    time.sleep(1)
    print("lol")