import time



f = open("panelvalues/cc", "r")
combo = f.read()

number=combo.split(":")[0]

exp=combo.split(":")[1]

sec = combo.split(":")[2]

print(number)
print(exp)
print(sec)